package com.rockthejvm
// https://www.scalatest.org/scaladoc/3.1.2/org/scalatest/funsuite/AnyFunSuite.html
import org.scalatest.funsuite.AnyFunSuite

class SimpleTest extends AnyFunSuite {
   test ("Simple Test") {
      assert("Scala".toLowerCase == "scala")
   }
}