package com.rockthe jvm
object CoreApp {
  def main (args: Array[String]): UNit = println ("Simple Module Application")  
}