object Constants {
    // We can have a bunch of packages.
    val rootPackage = "com.typesafe"
}