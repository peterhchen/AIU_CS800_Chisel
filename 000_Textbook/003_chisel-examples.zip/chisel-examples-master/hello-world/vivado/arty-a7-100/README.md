Vivado HOWTO:

1) make
2) start Vivado in this directory
3) Open Vivado and select Tools -> Run tcl script. The project will now be created in this folder.
4) Generate bitstream and configure the FPGA with Vivado.
